 "use client";
import { useMemo, useState } from "react";
import { ArrowDownRight, ArrowRight, Bell, CalendarDays, Check, ChevronDown, CircleHelp, CreditCard, Ellipsis, Filter, LayoutDashboard, Plus, Search, Settings2, Sparkles, TrendingUp, Wallet, X } from "lucide-react";

type Sub = { id:number; name:string; plan:string; amount:number; cycle:string; due:string; icon:string; color:string; status:"Active"|"Trial"|"Cancelled" };
const initial:Sub[] = [
 {id:1,name:"Adobe Creative Cloud",plan:"All Apps",amount:54.99,cycle:"monthly",due:"Nov 3, 2026",icon:"A",color:"#e75a51",status:"Active"},
 {id:2,name:"YouTube Premium",plan:"Individual",amount:12.99,cycle:"monthly",due:"Nov 5, 2026",icon:"▶",color:"#f14c4c",status:"Active"},
 {id:3,name:"Spotify Premium",plan:"Individual",amount:10.99,cycle:"monthly",due:"Nov 8, 2026",icon:"≋",color:"#29985b",status:"Active"},
 {id:4,name:"1Password",plan:"Families",amount:4.99,cycle:"monthly",due:"Nov 13, 2026",icon:"●",color:"#4766d8",status:"Active"},
 {id:5,name:"Netflix",plan:"Standard",amount:15.49,cycle:"monthly",due:"Nov 17, 2026",icon:"N",color:"#df343d",status:"Trial"}
];
const money=(n:number)=>new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"}).format(n);
export default function Home() {
 const [subs,setSubs]=useState(initial); const [query,setQuery]=useState(""); const [showAdd,setShowAdd]=useState(false);
 const [name,setName]=useState(""); const [amount,setAmount]=useState(""); const [tab,setTab]=useState("Overview");
 const visible=useMemo(()=>subs.filter(s=>s.name.toLowerCase().includes(query.toLowerCase())),[subs,query]);
 const monthly=subs.filter(s=>s.status==="Active").reduce((a,s)=>a+s.amount,0);
 function addSub(e:React.FormEvent){e.preventDefault();if(!name.trim()||!Number(amount)||Number(amount)<0)return;setSubs([{id:Date.now(),name:name.trim(),plan:"Personal plan",amount:Number(amount),cycle:"monthly",due:"Nov 20, 2026",icon:name.trim()[0].toUpperCase(),color:"#8274d9",status:"Active"},...subs]);setName("");setAmount("");setShowAdd(false);}
 return <main className="app-shell">
  <aside className="sidebar">
   <div className="brand"><span className="brand-mark"><Wallet size={19}/></span><span>subscription<span className="brand-light">hub</span></span></div>
   <div className="workspace-label">WORKSPACE <ChevronDown size={13}/></div>
   <nav>{[{label:"Overview",icon:LayoutDashboard},{label:"My subscriptions",icon:CreditCard},{label:"Calendar",icon:CalendarDays},{label:"Reminders",icon:Bell},{label:"Analytics",icon:TrendingUp}].map(({label,icon:Icon})=><button key={label} onClick={()=>setTab(label)} className={`nav-item ${tab===label?"active":""}`}><Icon size={17}/>{label}{label==="Reminders"&&<span className="nav-count">3</span>}</button>)}</nav>
   <div className="sidebar-bottom"><button className="nav-item" onClick={()=>setTab("Settings")}><Settings2 size={17}/>Settings</button><button className="nav-item" onClick={()=>setTab("Help & support")}><CircleHelp size={17}/>Help & support</button><div className="profile"><div className="avatar">SR</div><div><strong>My workspace</strong><small>Personal account</small></div><Ellipsis size={18} className="profile-more"/></div></div>
  </aside>
  <section className="main-area">
   <header className="topbar"><div className="crumb">Workspace <span>/</span> {tab}</div><div className="top-actions"><button className="icon-btn" aria-label="Notifications"><Bell size={18}/><i/></button><div className="top-avatar">SR</div></div></header>
   <div className="content">
    <div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> YOUR MONEY, IN GOOD ORDER</div><h1>Good morning <span>☀️</span></h1><p className="subhead">A little clarity for all the things you subscribe to.</p></div><button className="primary-btn" onClick={()=>setShowAdd(true)}><Plus size={17}/> Add subscription</button></div>
    <section className="stats-grid">
     <article className="stat-card projection"><div className="stat-top"><span>Estimated monthly spend</span><span className="stat-icon"><Wallet size={17}/></span></div><div className="stat-value">{money(monthly)}<span className="per"> / mo</span></div><div className="stat-foot"><span className="trend"><ArrowDownRight size={14}/> Keep an eye on renewals</span></div><div className="sparkline"><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/><span/></div></article>
     <article className="stat-card"><div className="stat-top"><span>Active subscriptions</span><span className="stat-icon green"><CreditCard size={17}/></span></div><div className="stat-value">{subs.filter(s=>s.status==="Active").length}<span className="per"> services</span></div><div className="stat-foot muted">Across your digital life</div><div className="mini-bars"><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/></div></article>
     <article className="stat-card"><div className="stat-top"><span>Coming up in 7 days</span><span className="stat-icon peach"><CalendarDays size={17}/></span></div><div className="stat-value">2<span className="per"> payments</span></div><div className="stat-foot muted">Next one in 3 days</div><div className="week-dots">{["M","T","W","T","F","S","S"].map((d,i)=><span className={i===2||i===4?"dot-on":""} key={i}>{d}</span>)}</div></article>
    </section>
    <div className="section-heading"><div><h2>Your subscriptions</h2><p>Everything recurring, all in one place.</p></div><button className="text-btn" onClick={()=>setTab("My subscriptions")}>View all <ArrowRight size={15}/></button></div>
    <section className="subs-card"><div className="table-toolbar"><div className="searchbox"><Search size={16}/><input aria-label="Search subscriptions" placeholder="Search subscriptions..." value={query} onChange={e=>setQuery(e.target.value)}/>{query&&<button onClick={()=>setQuery("")} aria-label="Clear search"><X size={14}/></button>}</div><button className="filter-btn" onClick={()=>setTab("Filters")}><Filter size={15}/> Filters</button></div>
     <div className="table-wrap"><table><thead><tr><th>SERVICE</th><th>PLAN</th><th>NEXT PAYMENT</th><th>AMOUNT</th><th>STATUS</th><th></th></tr></thead><tbody>{visible.map(s=><tr key={s.id}><td><div className="service"><span className="service-logo" style={{background:s.color}}>{s.icon}</span><strong>{s.name}</strong></div></td><td className="secondary">{s.plan}</td><td><span className="date">{s.due}</span></td><td><strong>{money(s.amount)}</strong><small className="cycle">/ month</small></td><td><span className={`badge ${s.status.toLowerCase()}`}><i/>{s.status}</span></td><td><button className="more-btn" aria-label={`Options for ${s.name}`} onClick={()=>setSubs(subs.filter(x=>x.id!==s.id))}><Ellipsis size={18}/></button></td></tr>)}</tbody></table>{visible.length===0&&<div className="empty">No subscriptions match “{query}”.</div>}</div>
     <div className="table-footer"><span>Showing <strong>{visible.length}</strong> of {subs.length} subscriptions</span><span className="footer-note"><Check size={14}/> Looking good so far</span></div>
    </section>
    <div className="bottom-grid"><section className="panel"><div className="panel-heading"><div><h3>Upcoming payments</h3><p>Plan ahead, not last minute.</p></div><button className="dots"><Ellipsis size={18}/></button></div>{subs.filter(s=>s.status==="Active").slice(0,3).map(s=><div className="payment-row" key={s.id}><span className="payment-icon" style={{color:s.color,background:s.color+"16"}}>{s.icon}</span><div className="payment-name"><strong>{s.name}</strong><small>{s.due}</small></div><strong>{money(s.amount)}</strong></div>)}</section>
     <section className="panel reminder-panel"><div className="panel-heading"><div><h3>Stay one step ahead</h3><p>Your next renewal is around the corner.</p></div><span className="reminder-illustration"><Bell size={22}/></span></div><div className="reminder-callout"><span className="reminder-dot"/><div><strong>Renewal coming up</strong><p>YouTube Premium renews in 5 days. Make sure it still works for you.</p></div></div><button className="text-btn" onClick={()=>setTab("Reminders")}>Manage reminders <ArrowRight size={15}/></button></section></div>
    <footer>Made for a little more peace of mind <span>·</span> Subscription Hub</footer>
   </div>
  </section>
  {showAdd&&<div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setShowAdd(false)}}><form className="modal" onSubmit={addSub}><div className="modal-head"><div><h2>Add a subscription</h2><p>Keep your recurring costs in one place.</p></div><button type="button" className="icon-btn" onClick={()=>setShowAdd(false)} aria-label="Close"><X size={18}/></button></div><label>Service name<input autoFocus value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Apple Music" required/></label><label>Monthly amount (USD)<input type="number" min="0.01" step="0.01" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="9.99" required/></label><div className="modal-actions"><button type="button" className="filter-btn" onClick={()=>setShowAdd(false)}>Cancel</button><button className="primary-btn" type="submit"><Plus size={16}/> Add subscription</button></div></form></div>}
 </main>
}