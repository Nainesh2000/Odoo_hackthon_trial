import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Subscription Hub — All your subscriptions, one place",
  description: "Track renewals, manage recurring costs, and stay ahead of every subscription."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}