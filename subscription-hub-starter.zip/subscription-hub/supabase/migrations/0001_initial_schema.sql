-- Subscription Hub foundational schema.
-- Apply only after reviewing in a non-production Supabase project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  preferred_currency text not null default 'USD' check (char_length(preferred_currency) = 3),
  timezone text not null default 'UTC',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.personal_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  service_name text not null check (char_length(trim(service_name)) between 1 and 120),
  plan_name text,
  amount numeric(12,2) not null check (amount >= 0),
  currency text not null default 'USD' check (char_length(currency) = 3),
  billing_interval text not null default 'monthly' check (billing_interval in ('daily','weekly','monthly','yearly','custom')),
  interval_count integer not null default 1 check (interval_count > 0),
  start_date date,
  next_renewal_date date,
  trial_end_date date,
  category text,
  payment_method_description text,
  status text not null default 'active' check (status in ('active','trial','paused','cancelled','expired')),
  notes text,
  data_source text not null default 'manual' check (data_source in ('manual','detected')),
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists personal_subscriptions_user_renewal_idx
  on public.personal_subscriptions(user_id, next_renewal_date);
create index if not exists personal_subscriptions_user_status_idx
  on public.personal_subscriptions(user_id, status);

create table if not exists public.personal_reminders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subscription_id uuid not null references public.personal_subscriptions(id) on delete cascade,
  scheduled_at timestamptz not null,
  reminder_offset_days integer not null check (reminder_offset_days in (7,3,1,0)),
  delivery_channel text not null default 'in_app' check (delivery_channel in ('in_app','email','push')),
  delivery_status text not null default 'scheduled' check (delivery_status in ('scheduled','sent','failed','cancelled')),
  attempt_count integer not null default 0,
  last_attempt_at timestamptz,
  failure_reason text,
  created_at timestamptz not null default now(),
  unique(subscription_id, scheduled_at, reminder_offset_days, delivery_channel)
);
create index if not exists personal_reminders_due_idx on public.personal_reminders(scheduled_at) where delivery_status = 'scheduled';

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(trim(name)) between 1 and 160),
  created_by uuid not null references auth.users(id),
  default_currency text not null default 'USD' check (char_length(default_currency) = 3),
  created_at timestamptz not null default now()
);
create table if not exists public.business_members (
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin','staff')),
  created_at timestamptz not null default now(),
  primary key (business_id, user_id)
);
create index if not exists business_members_user_idx on public.business_members(user_id, business_id);

alter table public.profiles enable row level security;
alter table public.personal_subscriptions enable row level security;
alter table public.personal_reminders enable row level security;
alter table public.businesses enable row level security;
alter table public.business_members enable row level security;

create policy "profiles_select_own" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profiles_insert_own" on public.profiles for insert to authenticated with check (id = auth.uid());
create policy "profiles_update_own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy "personal_subscriptions_select_own" on public.personal_subscriptions for select to authenticated using (user_id = auth.uid());
create policy "personal_subscriptions_insert_own" on public.personal_subscriptions for insert to authenticated with check (user_id = auth.uid());
create policy "personal_subscriptions_update_own" on public.personal_subscriptions for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "personal_subscriptions_delete_own" on public.personal_subscriptions for delete to authenticated using (user_id = auth.uid());

create policy "personal_reminders_select_own" on public.personal_reminders for select to authenticated using (user_id = auth.uid());
create policy "personal_reminders_insert_own" on public.personal_reminders for insert to authenticated with check (user_id = auth.uid());
create policy "personal_reminders_update_own" on public.personal_reminders for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "personal_reminders_delete_own" on public.personal_reminders for delete to authenticated using (user_id = auth.uid());

create policy "businesses_member_select" on public.businesses for select to authenticated using (
  exists (select 1 from public.business_members bm where bm.business_id = id and bm.user_id = auth.uid())
);
create policy "businesses_creator_insert" on public.businesses for insert to authenticated with check (created_by = auth.uid());
create policy "business_members_select_own" on public.business_members for select to authenticated using (user_id = auth.uid());
-- Membership changes should be implemented through trusted server-side functions with role checks.
